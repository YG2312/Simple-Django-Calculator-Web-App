from django.shortcuts import render

def index(request):
    result = ""
    if request.method == "POST":
        try:
            expression = request.POST.get('expression')
            result = eval(expression)
        except:
            result = "Error"
    return render(request, 'C:/Users/ACER/Desktop/calculator/calculator_project/calculator/templates/calculator/index.html', {'result': result})
